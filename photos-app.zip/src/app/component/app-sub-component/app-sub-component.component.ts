import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-sub-component',
  templateUrl: './app-sub-component.component.html',
  styleUrls: ['./app-sub-component.component.css']
})
export class AppSubComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
