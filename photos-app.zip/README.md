# AngularNodeFileUpload

Angular 8 Node & Express JS File Upload tutorial - Learn to create file uploading component in Angular using ng2-file-upload NPM package.

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.0.6.

## Start Frontend
- Git clone repo
- Run `npm install`
- Run `ng serve --open`

## Start Backend
- Get into the node server folder, run `cd backend`
- Run `npm install`
- Run `nodemon server.js`
